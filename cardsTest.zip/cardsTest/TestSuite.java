import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({CardTest.class, PlayerTest.class, CardDeckTest.class, HelperTest.class, CardGameTest.class})
public class TestSuite {}